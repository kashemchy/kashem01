count = 0
while count < 10:
    if count % 2 == 0:
        continue
    print(count, end=" ")
    count += 1
print()
