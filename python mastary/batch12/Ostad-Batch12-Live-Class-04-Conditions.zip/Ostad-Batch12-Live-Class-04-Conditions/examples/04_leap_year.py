# Leap Year Checker
# Concepts used: input(), int(), if-else, logical operators 'and' / 'or', % operator

year = int(input("Enter a year: "))

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
    print(year, "is a Leap Year")
else:
    print(year, "is not a Leap Year")
